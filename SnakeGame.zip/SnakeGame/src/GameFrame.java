import javax.swing.*;

class GameFrame extends JFrame {
    GameFrame(){

        this.add(new GamePanel());
        this.setTitle("SnakeGame"); //showing the title
        this.setResizable(false); //can not resize the panel
        this.pack(); //method  that
        this.setVisible(true); //make it visible
        this.setLocationRelativeTo(null); //show the panel in middle of our computer screen


    }
}