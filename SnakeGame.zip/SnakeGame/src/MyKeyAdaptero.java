public interface MyKeyAdaptero {
}
